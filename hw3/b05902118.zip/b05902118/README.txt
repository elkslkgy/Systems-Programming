Execution:
	Use "make" to compile all my source codes.
	Then run ./server [port] [logname]
	And then type URL
	URL could be 1.http://`yourip:12345/file_reader?filename=example_file
		     2.http://your_ip:port/info 
------------------------------------------------------
